import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;


public class Classroom {
	int h;
	int w;
	int troop;
	int x, y;
	String name;
	String owns;
	String building;
	Image io;
	

	public Classroom(int troops, int x2, int y2,int h1, int w1, String whatbuilding,String f) {
		troop = troops;
		x = x2;
		y = y2;
		owns = f;
		h=h1;
		w=w1;
		building=whatbuilding;
		URL url = getClass().getResource("arrow.png");
		System.out.println(url);
		try {
			io=(BufferedImage) ImageIO.read(url);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void addtroop(int n) {
		if (owns == "NT" || owns == "EN") {
			System.out.println("This is not your country");
		}
		else{
			troop+=n;
		}
	}

	public void attackorreinforce(Classroom r,int numtroops) {
		if(r.isyours()=="NT" || r.isyours()=="EN"){
		if (r.getnumtroops()  > numtroops) {
			r.setnumtroops(r.getnumtroops() - numtroops);
			owns = "YS";
		} else if (numtroops > r.getnumtroops() ) {
			this.setnumtroops(this.getnumtroops() - r.getnumtroops());
		} else {
			r.setnumtroops(1);
		}
		}
		else{
			r.addtroop(numtroops);
		}
	}

	public int getnumtroops() {
		return troop;
	}

	public void setnumtroops(int x) {
		troop = x;
	}

	public String named() {
		return name;
	}

	public int gety() {
		return y;
	}
	public int getx(){
		return x;
	}
	public String isyours(){
		return owns;
	}
	public void amountpathways(Graphics g){
		if(building == "Q1"){
		}
		if(building == "Q2"){
		}
		if(building == "Q3"){
		}
		if(building == "Q4"){
		}
		if(building == "Q5"){
		}
		if(building == "Q6"){
		}
		if(building == "Q7"){
		}
		if(building == "Q8"){
		}
		if(building == "Q9"){
		}
		if(building == "Q10"){
		}
		if(building == "Q11"){
		}
		if(building == "Q12"){
		}
		if(building == "SLGM"){
		}
		if(building == "THTR"){
		}
		if(building == "OFFC"){
		}
		if(building == "B1"){
		}
		if(building == "B2"){
		}
		if(building == "B3"){
		}
		if(building == "B4"){
		}
		if(building == "B5"){
		}
		if(building == "B6"){
		}
		if(building == "B7"){
		}
		if(building == "B8"){
		}
		if(building == "C1"){
		}
		if(building == "C2"){
		}
		if(building == "C3"){
		}
		if(building == "C4"){
		}
		if(building == "C5"){
		}
		if(building == "C6"){
		}
		if(building == "D1"){
		}
		if(building == "D2"){
		}
		if(building == "D3"){
		}
		if(building == "D4"){
		}
		if(building == "D5"){
		}
		if(building == "D6"){
		}
		if(building == "D7"){
			}
		if(building == "D8"){
			}
		if(building == "D9"){
			}
		if(building == "E1"){
			}
		if(building == "E2"){
			}
		if(building == "E3"){
			}
		if(building == "E4"){
			}
		if(building == "E5"){
			}
		if(building == "MP"){
		}
		if(building == "CONC"){
				}
		if(building == "G1"){
				}
		if(building == "G2"){
				}
		if(building == "G3"){
				}
		if(building == "G4"){
				}
		if(building == "G5"){
				}
		if(building == "H1"){
				}
		if(building == "H2"){
				}
		if(building == "H3"){
			}
		if(building == "H4"){
		}
		if(building == "H5"){
		}
		if(building == "H6"){
		}
		if(building == "H7"){
		}
		if(building == "H8"){
		}
		if(building == "H9"){
		}
		if(building == "H10"){
		}
		if(building == "H11"){
		}
		if(building == "H12"){
		}
		if(building == "I1"){
		}
		if(building == "I2"){
		}
		if(building == "I3"){
		}
		if(building == "I4"){
		}
		if(building == "I5"){
		}
		if(building == "I6"){
		}
		if(building == "I7"){
		}
		if(building == "I8"){
		}
		if(building == "I9"){
		}
		if(building == "I10"){
		}
		if(building == "J1"){
		}
		if(building == "J2"){
		}
		if(building == "J3"){
		}
		if(building == "J4"){
		}
		if(building == "J5"){
		}
		if(building == "J6"){
		}
		if(building == "J7"){
		}
		if(building == "J8"){
		}
		if(building == "L1"){
		}
		if(building == "L2"){
		}
		if(building == "L3"){
		}
		if(building == "L4"){
		}
		if(building == "L5"){
		}
		if(building == "L6"){
		}
		if(building == "M1"){
		}
		if(building == "M2"){
		}
		if(building == "M3"){
		}
		if(building == "M4"){
		}
		if(building == "M5"){
		}
		if(building == "M6"){
		}
		if(building == "M7"){
		}
		if(building == "M8"){
		}
		if(building == "M9"){
		}
		if(building == "CHR"){
		}
		if(building == "BND"){
		}
		if(building == "P1"){
		}
		if(building == "P2"){
		}
		if(building == "P3"){
		}
		if(building == "P4"){
		}
		if(building == "P5"){
		}
		if(building == "P6"){
		}
		if(building == "P7"){
		}
		if(building == "P8"){
		}
		if(building == "LGM"){
		}
		if(building == "POOL"){
		}
		}
	}
		
		
	


