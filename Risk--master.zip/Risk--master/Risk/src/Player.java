
public class Player {

	public Player() {
		// TODO Auto-generated constructor stub
	}
}
