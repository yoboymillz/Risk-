import java.awt.Graphics;
import java.util.ArrayList;

public class RiskBoard {

	int[] xcoord ={500,400,300,200,150,200,300,400,650,740};
	int[] ycoord = {500,500,500,500,450,200,200,200,200,450};
	int[] xcoordSide = {100,100,250,350,650};
	int[] ycoordSide = {350,300,125,125,500};
	ArrayList<Building> builds = new ArrayList();
	GraphicsPanel graph;

	
	public RiskBoard(GraphicsPanel graphicsPanel) {
		graph = graphicsPanel;
		builds = new ArrayList<Building>();
				builds.add(new Building(4));
				builds.add(new Building(2));
				builds.add(new Building(1));
				builds.add(new Building(4));
				builds.add(new Building(4));
				builds.add(new Building(4));
				builds.add(new Building(3));
				builds.add(new Building(4));
				builds.add(new Building(3));
				builds.add(new Building(5));
				builds.add(new Building(3));
				builds.add(new Building(6));
				builds.add(new Building(3));
				builds.add(new Building(5));
				builds.add(new Building(3));
				builds.add(new Building(3));
				builds.add(new Building(1));
				builds.get(0).addclassroom(new Classroom(2,548,512,20,20,"Q1","NT"));
				builds.get(0).addclassroom(new Classroom(2,549,537,20,20,"Q2","NT"));
				builds.get(0).addclassroom(new Classroom(2,574,511,20,20,"Q3","NT"));
				builds.get(0).addclassroom(new Classroom(2,575,543,20,20,"Q4","NT"));
				builds.get(0).addclassroom(new Classroom(2,599,512,20,20,"Q5","NT"));
				builds.get(0).addclassroom(new Classroom(2,598,541,20,20,"Q6","NT"));
				builds.get(0).addclassroom(new Classroom(2,648,545,20,20,"Q7","NT"));
				builds.get(0).addclassroom(new Classroom(2,671,526,20,20,"Q8","NT"));
				builds.get(0).addclassroom(new Classroom(2,671,486,20,20,"Q9","NT"));
				builds.get(0).addclassroom(new Classroom(2,691,506,20,20,"Q10","NT"));
				builds.get(0).addclassroom(new Classroom(2,692,465,20,20,"Q11","NT"));
				builds.get(0).addclassroom(new Classroom(2,713,485,20,20,"Q12","NT"));
				builds.get(1).addclassroom(new Classroom(2,451,392,20,20,"SLGM","NT"));
				builds.get(1).addclassroom(new Classroom(2,433,487,20,20,"THTR","NT"));
				builds.get(2).addclassroom(new Classroom(2,336,458,20,20,"OFFC","NT"));
				builds.get(3).addclassroom(new Classroom(2,264,537,20,20,"B1","NT"));
				builds.get(3).addclassroom(new Classroom(2,263,516,20,20,"B2","NT"));
				builds.get(3).addclassroom(new Classroom(2,262,498,20,20,"B3","NT"));
				builds.get(3).addclassroom(new Classroom(2,264,459,20,20,"B4","NT"));
				builds.get(3).addclassroom(new Classroom(2,263,440,20,20,"B5","NT"));
				builds.get(3).addclassroom(new Classroom(2,262,422,20,20,"B6","NT"));
				builds.get(3).addclassroom(new Classroom(2,263,403,20,20,"B7","NT"));
				builds.get(3).addclassroom(new Classroom(2,262,384,20,20,"B8","NT"));
				builds.get(4).addclassroom(new Classroom(2,197,535,20,20,"C1","NT"));
				builds.get(4).addclassroom(new Classroom(2,196,518,20,20,"C2","NT"));
				builds.get(4).addclassroom(new Classroom(2,196,497,20,20,"C3","NT"));
				builds.get(4).addclassroom(new Classroom(2,197,449,20,20,"C4","NT"));
				builds.get(4).addclassroom(new Classroom(2,197,415,20,20,"C5","NT"));
				builds.get(4).addclassroom(new Classroom(2,197,388,20,20,"C6","NT"));
				builds.get(5).addclassroom(new Classroom(2,150,389,20,20,"D1","NT"));
				builds.get(5).addclassroom(new Classroom(2,150,417,20,20,"D2","NT"));
				builds.get(5).addclassroom(new Classroom(2,150,448,20,20,"D3","NT"));
				builds.get(5).addclassroom(new Classroom(2,127,447,20,20,"D4","NT"));
				builds.get(5).addclassroom(new Classroom(2,128,419,20,20,"D5","NT"));
				builds.get(5).addclassroom(new Classroom(2,127,388,20,20,"D6","NT"));
				builds.get(5).addclassroom(new Classroom(2,149,490,20,20,"D7","NT"));
				builds.get(5).addclassroom(new Classroom(2,129,490,20,20,"D8","NT"));
				builds.get(5).addclassroom(new Classroom(2,127,517,20,20,"D9","NT"));
				builds.get(6).addclassroom(new Classroom(2,87,404,20,20,"E1","NT"));
				builds.get(6).addclassroom(new Classroom(2,88,462,20,20,"E2","NT"));
				builds.get(6).addclassroom(new Classroom(2,61,457,20,20,"E3","NT"));
				builds.get(6).addclassroom(new Classroom(2,61,414,20,20,"E4","NT"));
				builds.get(6).addclassroom(new Classroom(2,87,381,20,20,"E5","NT"));
				builds.get(7).addclassroom(new Classroom(2,42,289,20,20,"MP","NT"));
				builds.get(7).addclassroom(new Classroom(2,116,288,20,20,"CONC","NT"));
				builds.get(8).addclassroom(new Classroom(2,73,217,20,20,"G1","NT"));
				builds.get(8).addclassroom(new Classroom(2,48,246,20,20,"G2","NT"));
				builds.get(8).addclassroom(new Classroom(2,21,246,20,20,"G3","NT"));
				builds.get(8).addclassroom(new Classroom(2,23,227,20,20,"G4","NT"));
				builds.get(8).addclassroom(new Classroom(2,47,216,20,20,"G5","NT"));
				builds.get(9).addclassroom(new Classroom(2,244,236,20,20,"H1","NT"));
				builds.get(9).addclassroom(new Classroom(2,219,222,20,20,"H2","NT"));
				builds.get(9).addclassroom(new Classroom(2,194,222,20,20,"H3","NT"));
				builds.get(9).addclassroom(new Classroom(2,160,214,20,20,"H4","NT"));
				builds.get(9).addclassroom(new Classroom(2,244,215,20,20,"H5","NT"));
				builds.get(9).addclassroom(new Classroom(2,220,202,20,20,"H6","NT"));
				builds.get(9).addclassroom(new Classroom(2,196,201,20,20,"H7","NT"));
				builds.get(9).addclassroom(new Classroom(2,160,186,20,20,"H8","NT"));
				builds.get(9).addclassroom(new Classroom(2,160,158,20,20,"H9","NT"));
				builds.get(9).addclassroom(new Classroom(2,195,175,20,20,"H10","NT"));
				builds.get(9).addclassroom(new Classroom(2,219,180,20,20,"H11","NT"));
				builds.get(9).addclassroom(new Classroom(2,246,180,20,20,"H12","NT"));
				builds.get(10).addclassroom(new Classroom(2,294,139,20,20,"I1","NT"));
				builds.get(10).addclassroom(new Classroom(2,274,140,20,20,"I2","NT"));
				builds.get(10).addclassroom(new Classroom(2,254,140,20,20,"I3","NT"));
				builds.get(10).addclassroom(new Classroom(2,235,140,20,20,"I4","NT"));
				builds.get(10).addclassroom(new Classroom(2,208,140,20,20,"I5","NT"));
				builds.get(10).addclassroom(new Classroom(2,208,126,20,20,"I6","NT"));
				builds.get(10).addclassroom(new Classroom(2,227,125,20,20,"I7","NT"));
				builds.get(10).addclassroom(new Classroom(2,249,126,20,20,"I8","NT"));
				builds.get(10).addclassroom(new Classroom(2,268,126,20,20,"I9","NT"));
				builds.get(10).addclassroom(new Classroom(2,288,126,20,20,"I10","NT"));
				builds.get(11).addclassroom(new Classroom(2,304,180,20,20,"J1","NT"));
				builds.get(11).addclassroom(new Classroom(2,327,179,20,20,"J2","NT"));
				builds.get(11).addclassroom(new Classroom(2,348,179,20,20,"J3","NT"));
				builds.get(11).addclassroom(new Classroom(2,371,180,20,20,"J4","NT"));
				builds.get(11).addclassroom(new Classroom(2,370,206,20,20,"J5","NT"));
				builds.get(11).addclassroom(new Classroom(2,371,233,20,20,"J6","NT"));
				builds.get(11).addclassroom(new Classroom(2,370,255,20,20,"J7","NT"));
				builds.get(11).addclassroom(new Classroom(2,370,278,20,20,"J8","NT"));
				builds.get(12).addclassroom(new Classroom(2,405,144,20,20,"L1","NT"));
				builds.get(12).addclassroom(new Classroom(2,374,145,20,20,"L2","NT"));
				builds.get(12).addclassroom(new Classroom(2,344,144,20,20,"L3","NT"));
				builds.get(12).addclassroom(new Classroom(2,344,127,20,20,"L4","NT"));
				builds.get(12).addclassroom(new Classroom(2,374,127,20,20,"L5","NT"));
				builds.get(12).addclassroom(new Classroom(2,406,129,20,20,"L6","NT"));
				builds.get(13).addclassroom(new Classroom(2,472,210,20,20,"M1","NT"));
				builds.get(13).addclassroom(new Classroom(2,446,210,20,20,"M2","NT"));
				builds.get(13).addclassroom(new Classroom(2,424,210,20,20,"M3","NT"));
				builds.get(13).addclassroom(new Classroom(2,410,222,20,20,"M4","NT"));
				builds.get(13).addclassroom(new Classroom(2,410,200,20,20,"M5","NT"));
				builds.get(13).addclassroom(new Classroom(2,411,179,20,20,"M6","NT"));
				builds.get(13).addclassroom(new Classroom(2,426,179,20,20,"M7","NT"));
				builds.get(13).addclassroom(new Classroom(2,446,176,20,20,"M8","NT"));
				builds.get(13).addclassroom(new Classroom(2,472,180,20,20,"M9","NT"));
				builds.get(14).addclassroom(new Classroom(2,448,126,20,20,"CHR","NT"));
				builds.get(14).addclassroom(new Classroom(2,493,127,20,20,"BND","NT"));
				builds.get(15).addclassroom(new Classroom(2,656,156,20,20,"P1","NT"));
				builds.get(15).addclassroom(new Classroom(2,631,156,20,20,"P2","NT"));
				builds.get(15).addclassroom(new Classroom(2,606,156,20,20,"P3","NT"));
				builds.get(15).addclassroom(new Classroom(2,581,156,20,20,"P4","NT"));
				builds.get(15).addclassroom(new Classroom(2,557,156,20,20,"P5","NT"));
				builds.get(15).addclassroom(new Classroom(2,556,123,20,20,"P6","NT"));
				builds.get(15).addclassroom(new Classroom(2,581,123,20,20,"P7","NT"));
				builds.get(15).addclassroom(new Classroom(2,606,123,20,20,"P8","NT"));
				builds.get(16).addclassroom(new Classroom(2,557,189,20,20,"LGM","NT"));
				builds.get(16).addclassroom(new Classroom(2,531,287,20,20,"POOL","NT"));
				
				
	
	}
	
	public void draw(Graphics g){
		for(int x = 0; x<builds.size();x++){
			builds.get(x).drawBuilding(g, xcoord[x], ycoord[x]);	
		}
		
		
	}
	public void Clickloc(Graphics g, int tX, int tY) {
		if(graph.isPressed() == true){
			for(int x = 0; x<builds.size();x++){
				if(graph.getmouseX() <=xcoord[x]+40 && graph.getmouseX() >=xcoord[x] 
						&& graph.getmouseY() >= ycoord[x] &&graph.getmouseY() <= ycoord[x]+60){
					builds.get(x).click(g, xcoord[x], ycoord[x]);
				}

			}
			
		}
	}
	

}