import java.awt.Graphics;
import java.util.ArrayList;

public class RiskBoard {

	int[] xcoord ={500,400,300,200,150,200,300,400,650,740};
	int[] ycoord = {500,500,500,500,450,200,200,200,200,450};
	int[] xcoordSide = {100,100,250,350,650};
	int[] ycoordSide = {350,300,125,125,500};
	
	GraphicsPanel graph;

	
	public RiskBoard(GraphicsPanel graphicsPanel) {
		graph = graphicsPanel;
		ArrayList<Classroom> Q= new ArrayList<Classroom>();
		ArrayList<Classroom> SLTH= new ArrayList<Classroom>();
		ArrayList<Classroom> B= new ArrayList<Classroom>();
		ArrayList<Classroom> C= new ArrayList<Classroom>();
		ArrayList<Classroom> D= new ArrayList<Classroom>();
		ArrayList<Classroom> E= new ArrayList<Classroom>();
		ArrayList<Classroom> F= new ArrayList<Classroom>();
		ArrayList<Classroom> G= new ArrayList<Classroom>();
		ArrayList<Classroom> H= new ArrayList<Classroom>();
		ArrayList<Classroom> I= new ArrayList<Classroom>();
		ArrayList<Classroom> J= new ArrayList<Classroom>();
		ArrayList<Classroom> K= new ArrayList<Classroom>();
		ArrayList<Classroom> L= new ArrayList<Classroom>();
		ArrayList<Classroom> M= new ArrayList<Classroom>();
		ArrayList<Classroom> P= new ArrayList<Classroom>();
		ArrayList<Classroom> off= new ArrayList<Classroom>();
		ArrayList<Classroom> MPC= new ArrayList<Classroom>();
		ArrayList<Classroom> PLGM= new ArrayList<Classroom>();
		ArrayList<Classroom>BND= new ArrayList<Classroom>();
		
				Q.add(new Classroom(2,548,512,20,20,"Q1","NT"));
				Q.add(new Classroom(2,549,537,20,20,"Q2","NT"));
				Q.add(new Classroom(2,574,511,20,20,"Q3","NT"));
				Q.add(new Classroom(2,575,543,20,20,"Q4","NT"));
				Q.add(new Classroom(2,599,512,20,20,"Q5","NT"));
				Q.add(new Classroom(2,598,541,20,20,"Q6","NT"));
				Q.add(new Classroom(2,648,545,20,20,"Q7","NT"));
				Q.add(new Classroom(2,671,526,20,20,"Q8","NT"));
				Q.add(new Classroom(2,671,486,20,20,"Q9","NT"));
				Q.add(new Classroom(2,691,506,20,20,"Q10","NT"));
				Q.add(new Classroom(2,692,465,20,20,"Q11","NT"));
				Q.add(new Classroom(2,713,485,20,20,"Q12","NT"));
				SLTH.add(new Classroom(2,451,392,20,20,"SLGM","NT"));
				SLTH.add(new Classroom(2,433,487,20,20,"THTR","NT"));
				off.add(new Classroom(2,336,458,20,20,"OFFC","NT"));
				B.add(new Classroom(2,264,537,20,20,"B1","NT"));
				B.add(new Classroom(2,263,516,20,20,"B2","NT"));
				B.add(new Classroom(2,262,498,20,20,"B3","NT"));
				B.add(new Classroom(2,264,459,20,20,"B4","NT"));
				B.add(new Classroom(2,263,440,20,20,"B5","NT"));
				B.add(new Classroom(2,262,422,20,20,"B6","NT"));
				B.add(new Classroom(2,263,403,20,20,"B7","NT"));
				B.add(new Classroom(2,262,384,20,20,"B8","NT"));
				C.add(new Classroom(2,197,535,20,20,"C1","NT"));
				C.add(new Classroom(2,196,518,20,20,"C2","NT"));
				C.add(new Classroom(2,196,497,20,20,"C3","NT"));
				C.add(new Classroom(2,197,449,20,20,"C4","NT"));
				C.add(new Classroom(2,197,415,20,20,"C5","NT"));
				C.add(new Classroom(2,197,388,20,20,"C6","NT"));
				D.add(new Classroom(2,150,389,20,20,"D1","NT"));
				D.add(new Classroom(2,150,417,20,20,"D2","NT"));
				D.add(new Classroom(2,150,448,20,20,"D3","NT"));
				D.add(new Classroom(2,127,447,20,20,"D4","NT"));
				D.add(new Classroom(2,128,419,20,20,"D5","NT"));
				D.add(new Classroom(2,127,388,20,20,"D6","NT"));
				D.add(new Classroom(2,149,490,20,20,"D7","NT"));
				D.add(new Classroom(2,129,490,20,20,"D8","NT"));
				D.add(new Classroom(2,127,517,20,20,"D9","NT"));
				E.add(new Classroom(2,87,404,20,20,"E1","NT"));
				E.add(new Classroom(2,88,462,20,20,"E2","NT"));
				E.add(new Classroom(2,61,457,20,20,"E3","NT"));
				E.add(new Classroom(2,61,414,20,20,"E4","NT"));
				E.add(new Classroom(2,87,381,20,20,"E5","NT"));
				MPC.add(new Classroom(2,42,289,20,20,"MP","NT"));
				MPC.add(new Classroom(2,116,288,20,20,"CONC","NT"));
				G.add(new Classroom(2,73,217,20,20,"G1","NT"));
				G.add(new Classroom(2,48,246,20,20,"G2","NT"));
				G.add(new Classroom(2,21,246,20,20,"G3","NT"));
				G.add(new Classroom(2,23,227,20,20,"G4","NT"));
				G.add(new Classroom(2,47,216,20,20,"G5","NT"));
				H.add(new Classroom(2,244,236,20,20,"H1","NT"));
				H.add(new Classroom(2,219,222,20,20,"H2","NT"));
				H.add(new Classroom(2,194,222,20,20,"H3","NT"));
				H.add(new Classroom(2,160,214,20,20,"H4","NT"));
				H.add(new Classroom(2,244,215,20,20,"H5","NT"));
				H.add(new Classroom(2,220,202,20,20,"H6","NT"));
				H.add(new Classroom(2,196,201,20,20,"H7","NT"));
				H.add(new Classroom(2,160,186,20,20,"H8","NT"));
				H.add(new Classroom(2,160,158,20,20,"H9","NT"));
				H.add(new Classroom(2,195,175,20,20,"H10","NT"));
				H.add(new Classroom(2,219,180,20,20,"H11","NT"));
				H.add(new Classroom(2,246,180,20,20,"H12","NT"));
				I.add(new Classroom(2,294,139,20,20,"I1","NT"));
				I.add(new Classroom(2,274,140,20,20,"I2","NT"));
				I.add(new Classroom(2,254,140,20,20,"I3","NT"));
				I.add(new Classroom(2,235,140,20,20,"I4","NT"));
				I.add(new Classroom(2,208,140,20,20,"I5","NT"));
				I.add(new Classroom(2,208,126,20,20,"I6","NT"));
				I.add(new Classroom(2,227,125,20,20,"I7","NT"));
				I.add(new Classroom(2,249,126,20,20,"I8","NT"));
				I.add(new Classroom(2,268,126,20,20,"I9","NT"));
				I.add(new Classroom(2,288,126,20,20,"I10","NT"));
				J.add(new Classroom(2,304,180,20,20,"J1","NT"));
				J.add(new Classroom(2,327,179,20,20,"J2","NT"));
				J.add(new Classroom(2,348,179,20,20,"J3","NT"));
				J.add(new Classroom(2,371,180,20,20,"J4","NT"));
				J.add(new Classroom(2,370,206,20,20,"J5","NT"));
				J.add(new Classroom(2,371,233,20,20,"J6","NT"));
				J.add(new Classroom(2,370,255,20,20,"J7","NT"));
				J.add(new Classroom(2,370,278,20,20,"J8","NT"));
				L.add(new Classroom(2,405,144,20,20,"L1","NT"));
				L.add(new Classroom(2,374,145,20,20,"L2","NT"));
				L.add(new Classroom(2,344,144,20,20,"L3","NT"));
				L.add(new Classroom(2,344,127,20,20,"L4","NT"));
				L.add(new Classroom(2,374,127,20,20,"L5","NT"));
				L.add(new Classroom(2,406,129,20,20,"L6","NT"));
				M.add(new Classroom(2,472,210,20,20,"M1","NT"));
				M.add(new Classroom(2,446,210,20,20,"M2","NT"));
				M.add(new Classroom(2,424,210,20,20,"M3","NT"));
				M.add(new Classroom(2,410,222,20,20,"M4","NT"));
				M.add(new Classroom(2,410,200,20,20,"M5","NT"));
				M.add(new Classroom(2,411,179,20,20,"M6","NT"));
				M.add(new Classroom(2,426,179,20,20,"M7","NT"));
				M.add(new Classroom(2,446,176,20,20,"M8","NT"));
				M.add(new Classroom(2,472,180,20,20,"M9","NT"));
				BND.add(new Classroom(2,448,126,20,20,"CHR","NT"));
				BND.add(new Classroom(2,493,127,20,20,"BND","NT"));
				P.add(new Classroom(2,656,156,20,20,"P1","NT"));
				P.add(new Classroom(2,631,156,20,20,"P2","NT"));
				P.add(new Classroom(2,606,156,20,20,"P3","NT"));
				P.add(new Classroom(2,581,156,20,20,"P4","NT"));
				P.add(new Classroom(2,557,156,20,20,"P5","NT"));
				P.add(new Classroom(2,556,123,20,20,"P6","NT"));
				P.add(new Classroom(2,581,123,20,20,"P7","NT"));
				P.add(new Classroom(2,606,123,20,20,"P8","NT"));
				PLGM.add(new Classroom(2,557,189,20,20,"LGM","NT"));
				PLGM.add(new Classroom(2,531,287,20,20,"POOL","NT"));
				
				
	
	
	}
	
	public void drawarraows(Graphics g){
		
	}
	

}